#! /usr/bin/env python3
import rospy

# for the Odometry
from geometry_msgs.msg import PoseStamped, PoseArray
from move_base_msgs.msg import MoveBaseActionGoal
from actionlib_msgs.msg import GoalStatusArray

from robot_goal import robot_goal


class multi_goal_path_planning:
    def __init__(self):
        self.robots = self.get_robot_no()

        rospy.init_node('goal_client')
        self.goal_assignments = rospy.Subscriber('/swarm_search/assigned_goals', PoseArray, self.move_base_split,
                                                 queue_size=1)

        self.pub_goal = []
        self.subscriber_move_base_status = []

        for i in self.robots:
            self.pub_goal.append(rospy.Publisher(i + "/move_base/goal", MoveBaseActionGoal, queue_size=1))
            self.subscriber_move_base_status.append(rospy.Subscriber(i + '/move_base/status', GoalStatusArray,
                                                                self.get_status, queue_size=1))

        self.goal_pose = PoseStamped()
        self.goal_action = MoveBaseActionGoal()

        self.previous_goal_id = None
        self.new_goal_id = None
        self.state = None
        self.goal_counter = 0

        self.goal_list = []  # self.array([])

    def get_robot_no(self):
        robots = []
        number = 1
        robot_no = rospy.get_param("robot_no")

        while len(robots) < robot_no:
            robots.append("/rosbot" + str(number))
            number += 1

        return robots

    def move_base_split(self, msg):

        n = 0
        for pose in msg.poses:
            self.goalaction.movebasegoal.PoseStamped.pose = pose
            self.pub_goal[n].publish(self.goalaction)
            n+=1

    def get_status(self, status_msg):
        self.state = status_msg.status_list[0].status  # get the status of the goal, 3 is find
        self.current_goal_id = status_msg.status_list[0].goal_id.id

    def check_robot(self):  # check /status and computer vision
        None  # return true or false i guess

    # first need to publish soemthing before checking the call back --> it gives error right now

    def pub_firsttime(self):  # if it is the first time we just wait for the state to not be 3
        while (self.state != 3):
            self.pub_goal.publish(self.goal_action)
            rospy.sleep(1)
            print("I'm on it 1")
        self.goal_counter += 1  # goal is reached --> increment the counter

    def pub_function(self):
        # divided into 2 functions
        while (
                self.current_goal_id != self.new_goal_id):  # check if the goal has been update by checking if the id of the goal in the topic is the same as the one we sent from this file
            self.pub_goal.publish(self.goal_action)  # publish the goal
            rospy.sleep(1)
            print("i'm checking bro")
            print("goal number ", self.goal_counter)
            print(self.current_goal_id, "\n\n", self.new_goal_id, self.current_goal_id != self.new_goal_id)
        # we can add a if to check if msg.goal id the the same as new_goal
        while (
                self.state != 3):  # the goal is published --> we check if it arrived, later we can create a function that check both the status and the computer vision
            self.pub_goal.publish(self.goal_action)  # normally we don't need this line anymore
            rospy.sleep(1)
            print("I'm on it 2")
        self.goal_counter += 1  # goal is reached --> increment the counter

    # =============== GOAL #===============
    def create_goal(self, x, y, z, roll, pitch, yaw, w):  # create a goal and put it in the goal list
        new_goal = robot_goal(x, y, z, roll, pitch, yaw, w)
        self.goal_list.append(new_goal)

    def update_goal(self,
                    next_robot_goal):  # goal_action is a MoveBaseActionGoal, it includes a PoseStamped object (=goal_pose) with the same information
        # ...
        self.goal_pose.header.frame_id = "map"
        self.goal_pose.header.stamp = rospy.Time.now()

        self.goal_pose.pose.position.x = next_robot_goal.x
        self.goal_pose.pose.position.y = next_robot_goal.y
        self.goal_pose.pose.position.z = next_robot_goal.z

        self.goal_pose.pose.orientation.x = next_robot_goal.roll
        self.goal_pose.pose.orientation.y = next_robot_goal.pitch
        self.goal_pose.pose.orientation.z = next_robot_goal.yaw
        self.goal_pose.pose.orientation.w = next_robot_goal.w

        # ...
        self.goal_action.header = self.goal_pose.header

        self.goal_action.goal_id.stamp = self.goal_action.header.stamp
        self.goal_action.goal_id.id = "goal number" + str(self.goal_counter)
        self.new_goal_id = self.goal_action.goal_id.id

        self.goal_action.goal.target_pose = self.goal_pose  # update the goal_action

    def send_goal(self):  # function that call the publisher
        self.update_goal(self.goal_list[
                             self.goal_counter])  # put it somewhere else ?//#to update the goal we can either call self.goal_list[-1] wich take the last one if is add goal step by step OR we call self.goal_list[self.goal_counter]

        if (self.goal_counter == 0):  # if it is the irst time we call a specific publisher function
            self.update_goal(self.goal_list[0])
            self.pub_firsttime()

        else:
            self.pub_function()

    def send_goal_forloop(self):
        for i in range(len(self.goal_list)):
            self.send_goal()
            print("I'm running the foor loop")

    def main(self):
        #rospy.sleep(2)
        # self.create_goal(1,0,0,0,0,0,1)
        #self.create_goal(2, 2, 0, 0, 0, 0, 1)
        #self.create_goal(-1, 0, 0, 0, 0, 0, 1)
        rospy.sleep(1)
        #self.send_goal_forloop()



if __name__ == "__main__":
    my_goals = multi_goal_path_planning()
    my_goals.main()
    rospy.spin()
